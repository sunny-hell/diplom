function [particles] = prepareFirstSetAdaptiveSIR(state, w, h)
    global N
    % w, h - ������� �����
    positions = sampleUniform(w, h);
    particles = [positions(:,1) positions(:,2) repmat(state.w, N, 1) repmat(state.ar, N, 1) ...
                 zeros(N,1) zeros(N,1) zeros(N,1) zeros(N,1) ...
                 repmat(1/N, N, 1), repmat(1/N, N, 1).*(linspace(1,N,N)')];
end 
