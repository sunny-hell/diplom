function video_processing()
    global Q_TEMPL KOEFF SIGMA N N_BINS R ALPHA BETA ERF_COEFF A DEVS;
    clc;
    close all;
    N = 200;
    SIGMA = 0.01; % ����� ������ �������
    KOEFF = 1/sqrt(2*pi*SIGMA);
    N_BINS = 128;
    ALPHA = 8;
    BETA = 0.5;
    ERF_COEFF = 2/sqrt(pi); % ����������� ��� ������� ������ erf
    A =  [eye(4) eye(4); zeros(4) eye(4)];
    DEVS = [5.72 0.38 0.1 0.02 1.8 0.04 0.01 0.002]';
    hold off;
    
    fname_src = '..\sample_videos\movie01.avi';
    fname_gt = '..\gt\ferrari\movie01.txt';

    videoObj = VideoReader(fname_src);
    width = videoObj.Width;
    height = videoObj.Height;
    
    gt = readGroundTruthFerrariDS(fname_gt);
    
    state = getFirstStateFerrari01(gt);
    nFrames = state.lastFrame - state.firstFrame + 1;
    disp('get first state'); 
    rect = [state.x, state.y, state.w, state.w*state.ar];
    mov(1:nFrames) = struct('cdata', zeros(height, width, 3, 'uint8'),...
                           'colormap', []);
      
    mov(1).cdata = read(videoObj, state.firstFrame);
    
    disp('read first frame');
    hsvI = rgb2hsv(mov(1).cdata);
    templ_reg = imcrop(hsvI, rect);
    Q_TEMPL = getHSVHist(templ_reg);
    totalres = zeros(20, 2);
    fileID = fopen('mov01_results.txt', 'w');
    for iter=1:20
        state = getFirstStateFerrari01(gt);
        particles = prepareFirstSetAdaptiveSIR(state, width, height);
        disp('prepared first set');
        qInds = zeros(1, nFrames);
        for k=1:nFrames
            % process current frame
            t_start = tic;
            [particles] = processFrameAdaptiveSIR(mov(k).cdata, particles, state, gt(k, 2:5));
            t_stop = toc(t_start);
            disp(sprintf('Frame %d: %5.2f sec\n', k, t_stop));
            state.x = sum(particles(:,1).*particles(:,9));
            state.y = sum(particles(:,2).*particles(:,9));
            state.w = sum(particles(:,3).*particles(:,9)); 
            state.ar = sum(particles(:,4).*particles(:,9));
            estH = state.w*state.ar;
            estRect = [state.x state.y state.w estH];
%         if ((k == 1) || ...
%             (rem(k,5) == 0))  ...
%             ...
%            h=figure(k);
%            imshow(mov(k).cdata);
%            hold on;
%            
%            rectangle('Position', estRect, 'LineWidth',2, 'EdgeColor','b');
%            fname = sprintf('ferrari01_results_adaptive\\%d', k+state.firstFrame-1); 
%            saveas(h, fname, 'jpg');
%         end
            gtRect = [gt(k, 2:4) gt(k, 4).*gt(k, 5)];
            qInds(k) = qualityIndex(estRect, gtRect);
        % get next frame
            if (k < nFrames && iter==1)
                mov(k+1).cdata = read(videoObj, k+state.firstFrame);
            end
        end
        totalres(iter,1) = sum(qInds)/nFrames;
        qsum = 0;
        for k=1:nFrames
            qsum = qsum + (qInds(k)-totalres(iter,1)).^2;
        end
        totalres(iter,2) = sqrt(qsum/nFrames);
        fprintf(fileID, '%e %e\n', totalres(iter, 1), totalres(iter,2));
        disp('iteration results: ');
        disp(totalres(iter,:));
    end
    fclose(fileID);
end
